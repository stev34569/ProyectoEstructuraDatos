/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author steve
 */
public class Main {

    static int arr[]={12,24,5,7,9};
    

    public static void main(String[] args) {
        //----------------recursividad----------------------
      //  System.out.println(recursion.factorial(5));
       //   System.out.println(recursion.buscarElmento(arr,0,5,arr.length-1));
       
       
        //---------------pilas -----------------------------
        //*stack pila = new stack();
        //System.out.println(pila.getLengt());
       // pila.push(1);
        //System.out.println(pila.getLengt());
       // pila.push(7);
       // pila.push(909090);
       // System.out.println(pila.getLengt());
        //pila.pop();
       // System.out.println(pila.getLengt());
        //-----------------------colas-----------------------
        
       // queue cola1 = new queue();
        //cola1.insertar(46);
        //cola1.insertar(12);
        //cola1.insertar(87);
        //cola1.insertar(125);
        //cola1.insertar(12);
        list miLista=new list();
        miLista.insertar(new Personas());
        
    }
    
}
