/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calse11;

/**
 *
 * @author steve
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        arbol.insertar(50);
        arbol.insertar(20);
        arbol.insertar(80);
        arbol.insertar(15);
        arbol.insertar(30);
        arbol.insertar(14);
         
    }

}
