/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author steve
 */
public class nodeL {
    Personas persona;
    nodeL next;

    public Personas getPersona() {
        return persona;
    }

    public void setPersona(Personas persona) {
        this.persona = persona;
    }

    public nodeL getNext() {
        return next;
    }

    public void setNext(nodeL next) {
        this.next = next;
    }

    public nodeL(Personas persona) {
        this.persona = persona;
    }
    
   
    
    
    
}
