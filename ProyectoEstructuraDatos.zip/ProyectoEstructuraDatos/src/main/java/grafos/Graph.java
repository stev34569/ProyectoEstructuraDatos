/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

/**
 *
 * @author steve
 */
public class Graph<T>{


    public int numVertices;//contamos vertices hay en el grafo
    public int maxCapacity;//capacidad maxima de vertice
    private T[] vertices;
    private int[][] edges; //Almacenamos las aristas

    //constructor
    public Graph(int maxVertices) {
        this.numVertices = 0;
        this.maxCapacity = maxVertices; //Definimos la capcidad maxima
        //this.vertices = new T[this.maxCapacity];
        this.edges = new int[this.maxCapacity][this.maxCapacity];
    }

    public void addVertex(T vertex) {

        //Validamos que haya campo en el grafo
        if (this.numVertices == this.maxCapacity) {
            System.out.println("El grafo ya esta lleno.");
            return;
        } else if (vertex != null) {
            System.out.println("No se puede insertar un grafo nulo");
            //return null;
        }
        this.vertices[this.numVertices] = vertex;
        for (int i = 0; i < this.numVertices; i++) {
            //Llenamos con 0 hasta que se le asigne un peso al arsita
            this.edges[this.numVertices][i] = 0;
            this.edges[i][this.numVertices] = 0;
        }
//Se incrementa la cuenta de vertices insertados
        this.numVertices++;
    }

    private int findVertex(T vertex) {
        for (int i = 0; i < this.vertices.length; i++) {
            if (this.vertices[i].equals(vertex)) {
                return i;
            }
        }
        return -1;
    }

    public int getWeidght(T fromVertex, T toVertex) {
        int row = findVertex(fromVertex);
        int column = findVertex(toVertex);
        if (row != -1 && column != -1) {
            return this.edges[row][column];
        } else {
            return -1;
        }
    }

    public void addEdge(T fromVertex, T toVertex, int weight) {
        int row = findVertex(fromVertex); //Encontrar el indice del primer vertice conectar
        int column = findVertex(toVertex); // Encontrar el indice del vertice que se desea conectar
        if (row != -1 && column != -1) {
            //Debido a que es un grafo no dirigido asignamos el peso en ambos   sentidos de la matriz
            
 this.edges[row][column] = weight;
            this.edges[column][row] = weight;
        } else {
            System.out.println("No se puede crear una arista entre vertices que no estan en el grafo");
 }
 }
}
